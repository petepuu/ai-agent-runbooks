#requires -Version 7.0
<#
.SYNOPSIS
    Configures Entra SAML SSO and its ServiceNow identity provider.
.DESCRIPTION
    Uses a local ServiceNow Basic API credential, signs in to Entra, creates or
    reuses the ServiceNow gallery app, and assigns the signed-in Entra user.
    Federation metadata comes from that app. IdP settings, the signing
    certificate, and its link are written and verified through the Table API.

    Activate Multi-Provider SSO and enroll an ACR recovery administrator with
    a local password and MFA first. Keep a recovery session open. The script
    does not disable ACR/MFA or change ServiceNow roles. It points
    glide.authenticate.sso.redirect.idp at this identity provider so logged-out
    users are sent to Entra. Local login remains at /side_door.do. Existing
    request-signing settings are preserved.
.PARAMETER Credential
    Local ServiceNow API username/password, for example int-saml. Not an Entra
    password or a browser MFA session. Basic API authentication must be allowed.
.PARAMETER ServiceNowInstance
    HTTPS instance URL. Defaults to https://dev469493.service-now.com.
.PARAMETER EnterpriseAppDisplayName
    Entra enterprise application name. Defaults to ServiceNow.
.PARAMETER EntraIDSAMLDisplayName
    ServiceNow identity provider name. Defaults to Microsoft Entra ID.
.PARAMETER UserField
    ServiceNow user field matched to the Entra NameID. Defaults to email.
.EXAMPLE
    .\Configure-ServiceNowSamlSso.ps1 -Credential $integrationCredential
.EXAMPLE
    .\Configure-ServiceNowSamlSso.ps1 -Credential (Get-Credential -UserName int-saml) -UserField user_name
.NOTES
    Requires Az.Accounts and delegated Graph access to read the current user,
    configure applications, and assign app roles (User.Read,
    Application.Read.All, AppRoleAssignment.ReadWrite.All or supported higher
    permissions), with an authorized Entra administrator role.

    ServiceNow requires read access to sys_user; read/update access to the SSO
    sys_properties records, including glide.authenticate.sso.redirect.idp;
    read/create/update access to saml2_update1_properties and sys_certificate;
    and read/create access to idp_certificate, including the configured fields.
    No dictionary access is needed.

    Existing app assignments are preserved. New assignments use the User role
    when that gallery role exists, otherwise the sole enabled user role, or
    Default Access when no app roles exist. An assignment can bring the user
    into provisioning scope if that service is running.
    Provisioning mappings and ServiceNow user roles are not configured here.

    Required ServiceNow fields are never dropped or retried. Only GET/PATCH HTTP
    404s for newly created Entra objects, and incomplete federation metadata,
    retry at most six times (62 seconds of backoff). If metadata is still
    incomplete, the tenant's standard Entra SAML URLs and the app's Graph
    token-signing certificate are used. Creation POSTs are never retried.
    Failed runs may leave earlier changes; correct the reported issue and rerun
    to reuse existing records.
.LINK
    https://learn.microsoft.com/en-us/entra/identity/saas-apps/servicenow-tutorial
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][ValidateNotNull()][pscredential]$Credential,
    [ValidateNotNullOrEmpty()][string]$ServiceNowInstance,
    [ValidateNotNullOrEmpty()][string]$EnterpriseAppDisplayName = 'ServiceNow',
    [ValidateNotNullOrEmpty()][string]$EntraIDSAMLDisplayName = 'Microsoft Entra ID',
    [ValidateNotNullOrEmpty()][string]$UserField = 'email'
)

$ErrorActionPreference = 'Stop'
$instanceUri = $null
if (-not [uri]::TryCreate($ServiceNowInstance, [UriKind]::Absolute, [ref]$instanceUri) -or
    $instanceUri.Scheme -ne 'https' -or $instanceUri.UserInfo -or
    $instanceUri.AbsolutePath -ne '/' -or $instanceUri.Query -or $instanceUri.Fragment) {
    throw 'ServiceNowInstance must be an HTTPS instance URL without a path, query, fragment, or embedded credentials.'
}
$ServiceNowInstance = $instanceUri.GetLeftPart([UriPartial]::Authority)
$identifier = $ServiceNowInstance
$replyUrl = "$ServiceNowInstance/navpage.do"

function Invoke-Graph {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [ValidateSet('Get', 'Post', 'Patch')][string]$Method = 'Get',
        [hashtable]$Body,
        [switch]$WaitForReplication
    )
    if ($WaitForReplication -and $Method -notin @('Get', 'Patch')) {
        throw 'Graph replication retries are only supported for GET and PATCH requests.'
    }
    $parameters = @{
        Method = $Method
        Uri = $Uri
        Headers = @{ Authorization = "Bearer $script:GraphToken"; Accept = 'application/json' }
        ErrorAction = 'Stop'
    }
    if ($null -ne $Body) {
        $parameters.ContentType = 'application/json'
        $parameters.Body = $Body | ConvertTo-Json -Compress -Depth 8
    }
    $maxRetries = if ($WaitForReplication) { 6 } else { 0 }
    for ($attempt = 0; $attempt -le $maxRetries; $attempt++) {
        try { return Invoke-RestMethod @parameters }
        catch {
            $status = if ($_.Exception.Response) { [int]$_.Exception.Response.StatusCode } else { 0 }
            if ($status -eq 404 -and $attempt -lt $maxRetries) {
                $delay = [int][Math]::Min(2 * [Math]::Pow(2, $attempt), 16)
                Write-Warning "Graph $Method $Uri returned HTTP 404 for a new object. Waiting $delay seconds (retry $($attempt + 1)/$maxRetries)."
                Start-Sleep -Seconds $delay
                continue
            }
            $detail = $_.ErrorDetails.Message
            if (-not $detail) { $detail = $_.Exception.Message }
            throw "Graph $Method $Uri failed after $($attempt + 1) attempt(s): $detail"
        }
    }
}

function ConvertTo-NormalizedCertificate {
    param([string]$CertificateText)
    $clean = (($CertificateText -replace '(?s)-----BEGIN CERTIFICATE-----', '') -replace '(?s)-----END CERTIFICATE-----', '') -replace '\s'
    if (-not $clean) { return $null }
    try {
        $parsed = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new([Convert]::FromBase64String($clean))
    }
    catch { return $null }
    try {
        [pscustomobject]@{ Base64 = $clean; Thumbprint = $parsed.Thumbprint.ToUpperInvariant() }
    }
    finally { $parsed.Dispose() }
}

function Get-EntraFederationMetadata {
    param(
        [Parameter(Mandatory)]$Response,
        [string]$SigningThumbprint
    )

    $metadataXml = if ($Response -is [string]) { $Response } elseif ($Response -is [xml]) { $Response.OuterXml } else { $null }
    if ([string]::IsNullOrWhiteSpace($metadataXml)) {
        throw "Federation metadata returned $($Response.GetType().FullName), not XML."
    }
    $metadata = [xml]$metadataXml.TrimStart([char]0xFEFF)
    $wanted = $SigningThumbprint.Replace(' ', '').ToUpperInvariant()
    $certNode = $metadata.SelectNodes('//*[local-name()="IDPSSODescriptor"]/*[local-name()="KeyDescriptor"][@use="signing"]//*[local-name()="X509Certificate"]') |
        ForEach-Object { ConvertTo-NormalizedCertificate $_.InnerText } |
        Where-Object { $_ -and (-not $wanted -or $_.Thumbprint -eq $wanted) } |
        Select-Object -First 1
    [pscustomobject]@{
        EntityId    = [string]$metadata.SelectSingleNode('//*[local-name()="EntityDescriptor"]').entityID
        SsoUrl      = [string]$metadata.SelectSingleNode('//*[local-name()="IDPSSODescriptor"]/*[local-name()="SingleSignOnService"][contains(@Binding,"HTTP-Redirect")]').Location
        SloUrl      = [string]$metadata.SelectSingleNode('//*[local-name()="IDPSSODescriptor"]/*[local-name()="SingleLogoutService"][contains(@Binding,"HTTP-Redirect")]').Location
        Certificate = [string]$certNode.Base64
        Root        = [string]$metadata.DocumentElement.LocalName
    }
}

function Set-CurrentUserAppAssignment {
    param(
        [Parameter(Mandatory)][object]$ServicePrincipal,
        [Parameter(Mandatory)][object]$User,
        [switch]$WaitForReplication
    )
    $resourceId = [guid]::Empty
    $principalId = [guid]::Empty
    if (-not [guid]::TryParse([string]$ServicePrincipal.id, [ref]$resourceId) -or
        $resourceId -eq [guid]::Empty -or
        -not [guid]::TryParse([string]$User.id, [ref]$principalId) -or $principalId -eq [guid]::Empty) {
        throw 'Graph did not return valid enterprise-app and current-user object IDs.'
    }
    # Filtering appRoleAssignedTo by principalId returns Request_UnsupportedQuery.
    # Graph supports the reverse lookup: the user's assignments filtered by resourceId.
    $assignmentPath = "/v1.0/servicePrincipals/$resourceId/appRoleAssignedTo"
    $listPath = "/v1.0/users/$($principalId.ToString('d'))/appRoleAssignments"
    $filter = [Uri]::EscapeDataString("resourceId eq $($resourceId.ToString('d'))")
    $uri = "https://graph.microsoft.com${listPath}?`$filter=$filter&`$select=id,principalId,resourceId,appRoleId"
    $visited = [System.Collections.Generic.HashSet[string]]::new()
    $assignment = $null
    do {
        if (-not $visited.Add($uri)) { throw 'Graph repeated an assignment pagination URL.' }
        $page = Invoke-Graph -Uri $uri -WaitForReplication:$WaitForReplication
        if ($page.value -isnot [array]) { throw 'Graph did not return an app-role assignment collection.' }
        $assignment = $page.value | Where-Object {
            [string]$_.principalId -eq $principalId.ToString('d') -and [string]$_.resourceId -eq $resourceId.ToString('d')
        } | Select-Object -First 1
        if ($assignment) { break }
        $uri = $page.'@odata.nextLink'
        if ($uri) {
            $next = $null
            if (-not [uri]::TryCreate([string]$uri, [UriKind]::Absolute, [ref]$next) -or
                $next.Scheme -ne 'https' -or $next.Host -ne 'graph.microsoft.com' -or
                -not $next.IsDefaultPort -or $next.UserInfo -or $next.Fragment -or $next.AbsolutePath -ne $listPath) {
                throw 'Graph returned an unexpected assignment pagination URL.'
            }
        }
    } while ($uri)
    $created = $false
    if (-not $assignment) {
        if ($null -eq $ServicePrincipal.appRoles) { throw 'Graph did not return the app role definitions.' }
        $roles = @($ServicePrincipal.appRoles)
        $userRoles = @($roles | Where-Object { $_.isEnabled -eq $true -and $_.allowedMemberTypes -contains 'User' })
        $roleId = [guid]::Empty
        $roleName = 'Default Access'
        if ($roles.Count -gt 0) {
            if ($userRoles.Count -eq 0) { throw 'The enterprise app has no enabled user role.' }
            $selected = @($userRoles | Where-Object { $_.value -eq 'User' -or $_.displayName -eq 'User' }) | Select-Object -First 1
            if (-not $selected -and $userRoles.Count -eq 1) { $selected = $userRoles[0] }
            if (-not $selected) {
                $names = @($userRoles | ForEach-Object { $_.displayName }) -join ', '
                throw "The enterprise app has multiple user roles ($names) and no User role. Assign the current user in Entra Users and groups first, then rerun."
            }
            if (-not [guid]::TryParse([string]$selected.id, [ref]$roleId) -or $roleId -eq [guid]::Empty) {
                throw 'Graph returned an invalid user app-role ID.'
            }
            $roleName = [string]$selected.displayName
        }
        Write-Host "Assigning Entra user $($User.userPrincipalName) to the enterprise app as '$roleName'"
        $assignment = Invoke-Graph -Method Post -Uri "https://graph.microsoft.com$assignmentPath" -Body @{
            principalId = $principalId.ToString(); resourceId = $resourceId.ToString(); appRoleId = $roleId.ToString()
        }
        if ([string]$assignment.principalId -ne [string]$principalId -or
            [string]$assignment.resourceId -ne [string]$resourceId -or [string]$assignment.appRoleId -ne [string]$roleId) {
            throw 'Graph did not confirm the expected user assignment. Inspect Users and groups before retrying.'
        }
        $created = $true
    }
    else { Write-Host "Entra user $($User.userPrincipalName) is already assigned" }
    $storedRole = [guid]::Empty
    if ([string]::IsNullOrWhiteSpace([string]$assignment.id) -or
        -not [guid]::TryParse([string]$assignment.appRoleId, [ref]$storedRole)) {
        throw 'Graph did not return valid assignment identifiers.'
    }
    $id = [Uri]::EscapeDataString([string]$assignment.id)
    $saved = Invoke-Graph -Uri "https://graph.microsoft.com${assignmentPath}/${id}?`$select=id,principalId,resourceId,appRoleId" -WaitForReplication:$created
    foreach ($field in @('id', 'principalId', 'resourceId', 'appRoleId')) {
        if ([string]$saved.$field -ne [string]$assignment.$field) { throw "Graph did not verify assignment field '$field'." }
    }
    return $saved
}

function Invoke-ServiceNowApi {
    param(
        [Parameter(Mandatory)][string]$RelativeUri,
        [ValidateSet('Get', 'Post', 'Patch')][string]$Method = 'Get',
        [hashtable]$Body
    )
    $parameters = @{
        Method = $Method
        Uri = "$ServiceNowInstance/api/now/table/$RelativeUri"
        Authentication = 'Basic'
        Credential = $Credential
        Headers = @{ Accept = 'application/json' }
        MaximumRedirection = 0
        ErrorAction = 'Stop'
    }
    if ($null -ne $Body) {
        $parameters.ContentType = 'application/json'
        $parameters.Body = $Body | ConvertTo-Json -Compress -Depth 6
    }
    try { $response = Invoke-RestMethod @parameters }
    catch {
        $status = if ($_.Exception.Response) { "HTTP $([int]$_.Exception.Response.StatusCode)" } else { 'no HTTP response' }
        $detail = $_.ErrorDetails.Message
        if (-not $detail) { $detail = $_.Exception.Message }
        throw "ServiceNow $Method $RelativeUri failed ($status): $detail. Verify local API credentials, table/field permissions, and the canonical instance URL."
    }
    if ($null -eq $response -or $response -is [string] -or $null -eq $response.result) {
        throw "ServiceNow $Method $RelativeUri returned no Table API JSON result. Interactive login or MFA pages cannot authenticate API calls."
    }
    return $response.result
}

Write-Host "Checking ServiceNow API access as $($Credential.UserName)"
$null = Invoke-ServiceNowApi -RelativeUri 'sys_user?sysparm_limit=1&sysparm_fields=sys_id'
$idpTable = 'saml2_update1_properties'
$idpQuery = [Uri]::EscapeDataString("name=$EntraIDSAMLDisplayName")
$existingIdp = @(Invoke-ServiceNowApi -RelativeUri "${idpTable}?sysparm_query=$idpQuery&sysparm_fields=sys_id&sysparm_limit=1") | Select-Object -First 1
$certQuery = [Uri]::EscapeDataString("name=$EntraIDSAMLDisplayName SAML")
$existingCert = @(Invoke-ServiceNowApi -RelativeUri "sys_certificate?sysparm_query=$certQuery&sysparm_fields=sys_id&sysparm_limit=1") | Select-Object -First 1
$null = Invoke-ServiceNowApi -RelativeUri 'idp_certificate?sysparm_fields=sys_id&sysparm_limit=1'
$multiSso = @(Invoke-ServiceNowApi -RelativeUri 'sys_properties?sysparm_query=name%3Dglide.authenticate.multisso.enabled&sysparm_fields=sys_id,value&sysparm_limit=1') | Select-Object -First 1
if (-not $multiSso.sys_id -or [string]$multiSso.value -notin @('true', 'false')) {
    throw 'The Multi-Provider SSO property is missing or unreadable. Verify the plugin and sys_properties.name/value read access.'
}

if (-not (Get-Module -ListAvailable -Name Az.Accounts)) {
    throw 'Az.Accounts is not installed. Run: Install-Module Az.Accounts -Scope CurrentUser'
}
Import-Module Az.Accounts -ErrorAction Stop
Connect-AzAccount -ErrorAction Stop | Out-Null
$context = Get-AzContext -ErrorAction Stop
if (-not $context.Tenant.Id) { throw 'Azure sign-in did not provide a tenant context.' }
$token = (Get-AzAccessToken -ResourceUrl 'https://graph.microsoft.com' -ErrorAction Stop).Token
$script:GraphToken = if ($token -is [securestring]) { [System.Net.NetworkCredential]::new('', $token).Password } else { [string]$token }
Write-Host "Using tenant: $($context.Tenant.Id) account: $($context.Account.Id)"
$signedInUser = Invoke-Graph -Uri 'https://graph.microsoft.com/v1.0/me?$select=id,userPrincipalName'
$signedInUserId = [guid]::Empty
if (-not [guid]::TryParse([string]$signedInUser.id, [ref]$signedInUserId) -or
    $signedInUserId -eq [guid]::Empty -or [string]::IsNullOrWhiteSpace([string]$signedInUser.userPrincipalName)) {
    throw 'Graph did not return the signed-in Entra user. Use an interactive user login with delegated Graph permissions.'
}

$newApplication = $false
$newServicePrincipal = $false
$appFilter = [Uri]::EscapeDataString("displayName eq '$($EnterpriseAppDisplayName.Replace("'", "''"))'")
$apps = Invoke-Graph -Uri "https://graph.microsoft.com/v1.0/applications?`$filter=$appFilter&`$select=id,appId,displayName"
$application = @($apps.value) | Select-Object -First 1
if ($application) {
    Write-Host "Reusing Entra app $($application.appId)"
    $principals = Invoke-Graph -Uri "https://graph.microsoft.com/v1.0/servicePrincipals?`$filter=appId eq '$($application.appId)'&`$select=id,appId"
    $servicePrincipal = @($principals.value) | Select-Object -First 1
    if (-not $servicePrincipal) {
        $servicePrincipal = Invoke-Graph -Method Post -Uri 'https://graph.microsoft.com/v1.0/servicePrincipals' -Body @{ appId = $application.appId }
        $newServicePrincipal = $true
    }
}
else {
    Write-Host 'Creating ServiceNow gallery enterprise app'
    $templates = Invoke-Graph -Uri "https://graph.microsoft.com/v1.0/applicationTemplates?`$filter=displayName eq 'ServiceNow'"
    $template = @($templates.value) | Where-Object { $_.displayName -eq 'ServiceNow' } | Select-Object -First 1
    if (-not $template.id) { throw 'The ServiceNow gallery template was not found.' }
    $createdApp = Invoke-Graph -Method Post -Uri "https://graph.microsoft.com/v1.0/applicationTemplates/$($template.id)/instantiate" -Body @{ displayName = $EnterpriseAppDisplayName }
    $application = $createdApp.application
    $servicePrincipal = $createdApp.servicePrincipal
    $newApplication = $true
    $newServicePrincipal = $true
}
if (-not $application.id -or -not $application.appId -or -not $servicePrincipal.id) {
    throw 'Graph did not return the application and service-principal identifiers.'
}

Write-Host 'Enabling SAML SSO on the enterprise app'
$null = Invoke-Graph -Method Patch -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$($servicePrincipal.id)" -WaitForReplication:$newServicePrincipal -Body @{
    preferredSingleSignOnMode = 'saml'; loginUrl = $replyUrl
}
$null = Invoke-Graph -Method Patch -Uri "https://graph.microsoft.com/v1.0/applications/$($application.id)" -WaitForReplication:$newApplication -Body @{
    identifierUris = @($identifier)
    web = @{ logoutUrl = $replyUrl; redirectUris = @($replyUrl, "$ServiceNowInstance/consumer.do") }
}
$servicePrincipal = Invoke-Graph -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$($servicePrincipal.id)?`$select=id,appId,preferredTokenSigningKeyThumbprint,appRoles" -WaitForReplication:$newServicePrincipal
$signingThumbprint = [string]$servicePrincipal.preferredTokenSigningKeyThumbprint
$signingCertificateKey = $null
if (-not $signingThumbprint) {
    Write-Host 'Creating Entra SAML signing certificate'
    $certificate = Invoke-Graph -Method Post -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$($servicePrincipal.id)/addTokenSigningCertificate" -Body @{
        displayName = 'CN=Microsoft Azure Federated SSO Certificate'
    }
    $signingThumbprint = [string]$certificate.thumbprint
    $signingCertificateKey = [string]$certificate.key
    if ([string]::IsNullOrWhiteSpace($signingThumbprint)) {
        throw 'Graph did not return the new SAML signing-certificate thumbprint. No ServiceNow records were changed.'
    }
    $null = Invoke-Graph -Method Patch -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$($servicePrincipal.id)" -WaitForReplication:$newServicePrincipal -Body @{
        preferredTokenSigningKeyThumbprint = $signingThumbprint
    }
}
if ([string]::IsNullOrWhiteSpace($signingThumbprint)) {
    throw 'The enterprise app has no SAML signing-certificate thumbprint. No ServiceNow records were changed.'
}
$currentUserAssignment = Set-CurrentUserAppAssignment -ServicePrincipal $servicePrincipal -User $signedInUser -WaitForReplication:$newServicePrincipal
$tenantId = [guid]::Empty
if (-not [guid]::TryParse([string]$context.Tenant.Id, [ref]$tenantId) -or $tenantId -eq [guid]::Empty) {
    throw 'Azure sign-in did not provide a tenant ID.'
}
$tenant = $tenantId.ToString('d')
$metadataUrl = "https://login.microsoftonline.com/$tenant/federationmetadata/2007-06/federationmetadata.xml?appid=$($application.appId)"
$redirectBinding = 'urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect'

Write-Host 'Reading federation metadata'
$metadata = [pscustomobject]@{ EntityId = ''; SsoUrl = ''; SloUrl = ''; Certificate = ''; Root = 'unreadable' }
for ($attempt = 0; $attempt -le 6; $attempt++) {
    try {
        $metadataResponse = Invoke-RestMethod -Method Get -Uri $metadataUrl -ErrorAction Stop
        $candidate = Get-EntraFederationMetadata -Response $metadataResponse -SigningThumbprint $signingThumbprint
        foreach ($name in 'EntityId', 'SsoUrl', 'SloUrl', 'Certificate') {
            if (-not $metadata.$name -and $candidate.$name) { $metadata.$name = $candidate.$name }
        }
        if ($candidate.Root) { $metadata.Root = $candidate.Root }
    }
    catch {
        Write-Warning "Federation metadata could not be read: $($_.Exception.Message)"
    }
    if ($metadata.EntityId -and $metadata.SsoUrl -and $metadata.SloUrl -and $metadata.Certificate) { break }
    if ($attempt -lt 6) {
        $delay = [int][Math]::Min(2 * [Math]::Pow(2, $attempt), 16)
        Write-Warning "Federation metadata is incomplete (root '$($metadata.Root)'). Waiting $delay seconds (retry $($attempt + 1)/6)."
        Start-Sleep -Seconds $delay
    }
}
$idpEntityId = $metadata.EntityId
$ssoUrl = $metadata.SsoUrl
$sloUrl = $metadata.SloUrl
if (-not $idpEntityId -or -not $ssoUrl -or -not $sloUrl) {
    Write-Warning 'Federation metadata did not include the IdP endpoints. Using the standard Entra SAML URLs.'
    if (-not $idpEntityId) { $idpEntityId = "https://sts.windows.net/$tenant/" }
    if (-not $ssoUrl) { $ssoUrl = "https://login.microsoftonline.com/$tenant/saml2" }
    if (-not $sloUrl) { $sloUrl = "https://login.microsoftonline.com/$tenant/saml2" }
}
foreach ($url in @($idpEntityId, $ssoUrl, $sloUrl)) {
    $parsedUrl = $null
    if (-not [uri]::TryCreate([string]$url, [UriKind]::Absolute, [ref]$parsedUrl) -or $parsedUrl.Scheme -ne 'https') {
        throw 'The IdP entity ID and SAML endpoints must be HTTPS URLs. No ServiceNow records were changed.'
    }
}
$parsedCertificate = ConvertTo-NormalizedCertificate $metadata.Certificate
if (-not $parsedCertificate) {
    if (-not $signingCertificateKey) {
        $credentialedPrincipal = Invoke-Graph -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$($servicePrincipal.id)?`$select=keyCredentials"
        $wanted = $signingThumbprint.Replace(' ', '').ToUpperInvariant()
        $match = @($credentialedPrincipal.keyCredentials) | Where-Object {
            $keyId = [string]$_.customKeyIdentifier
            $keyMatches = $false
            if ($_.key -and $keyId) {
                try { $keyMatches = (([BitConverter]::ToString([Convert]::FromBase64String($keyId)) -replace '-', '') -eq $wanted) }
                catch { $keyMatches = $false }
            }
            $keyMatches
        } | Select-Object -First 1
        $signingCertificateKey = [string]$match.key
    }
    $parsedCertificate = ConvertTo-NormalizedCertificate $signingCertificateKey
    if ($parsedCertificate) { Write-Warning 'Federation metadata did not include the app signing certificate. Using the Graph token-signing certificate.' }
}
if (-not $parsedCertificate -or $parsedCertificate.Thumbprint -ne $signingThumbprint.Replace(' ', '').ToUpperInvariant()) {
    throw "Federation metadata is incomplete (root '$($metadata.Root)') and no matching app signing certificate was available. No ServiceNow records were changed."
}
$pem = "-----BEGIN CERTIFICATE-----`n$($parsedCertificate.Base64)`n-----END CERTIFICATE-----"

if ($multiSso.value -ne 'true') {
    Write-Host 'Enabling ServiceNow Multi-Provider SSO'
    try {
        $null = Invoke-ServiceNowApi -Method Patch -RelativeUri "sys_properties/$($multiSso.sys_id)" -Body @{ value = 'true' }
    }
    catch {
        if ($_.Exception.Message -notmatch 'Check ACR and SSO') { throw }
        throw "ServiceNow's 'Check ACR and SSO' rule blocked enablement. Enroll a recovery administrator under Account Recovery with a local password and MFA, then rerun. Do not disable ACR or the rule. Original error: $($_.Exception.Message)"
    }
    $savedSso = Invoke-ServiceNowApi -RelativeUri "sys_properties/$($multiSso.sys_id)?sysparm_fields=value"
    if ($savedSso.value -ne 'true') { throw 'ServiceNow did not enable Multi-Provider SSO. Verify property write access, ACR enrollment, and SSO rules.' }
}

$idpBody = @{
    name = $EntraIDSAMLDisplayName
    active = 'true'
    idp = $idpEntityId
    idp_authnrequest_url = $ssoUrl
    idp_logout_url = $sloUrl
    idp_logout_binding = $redirectBinding
    issuer = $identifier
    audience = $identifier
    service_url = $replyUrl
    user_field = $UserField
    nameid_policy = 'urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress'
    sso_script = 'MultiSSOv2_SAML2_custom'
    clock_skew = 60
    createrequestedauthncontext = 'false'
    authncontextcassref_method = 'http://schemas.microsoft.com/ws/2008/06/identity/authenticationmethod/password'
    idp_metadata_url = $metadataUrl
}
if ($existingIdp.sys_id) {
    Write-Host "Updating ServiceNow IdP $($existingIdp.sys_id)"
    $idpId = $existingIdp.sys_id
    $null = Invoke-ServiceNowApi -Method Patch -RelativeUri "$idpTable/${idpId}?sysparm_input_display_value=true" -Body $idpBody
}
else {
    Write-Host 'Creating ServiceNow IdP'
    $createdIdp = Invoke-ServiceNowApi -Method Post -RelativeUri "${idpTable}?sysparm_input_display_value=true" -Body $idpBody
    $idpId = $createdIdp.sys_id
}
if ($idpId -notmatch '^[0-9a-f]{32}$') { throw 'ServiceNow did not return a valid identity provider sys_id.' }
$idpFields = ($idpBody.Keys | Sort-Object) -join ','
$savedIdp = Invoke-ServiceNowApi -RelativeUri "$idpTable/${idpId}?sysparm_fields=$idpFields&sysparm_display_value=all&sysparm_exclude_reference_link=true"
foreach ($field in $idpBody.Keys) {
    $value = $savedIdp.$field.value
    if ($field -eq 'sso_script') {
        if ($value -notmatch '^[0-9a-f]{32}$') { throw 'ServiceNow did not resolve MultiSSOv2_SAML2_custom to a valid script reference.' }
        $value = $savedIdp.$field.display_value
    }
    elseif ($field -in @('active', 'createrequestedauthncontext')) { $value = ([string]$value).ToLowerInvariant() }
    if ([string]$value -cne [string]$idpBody[$field]) {
        throw "ServiceNow did not persist SAML field '$field' on IdP $idpId. Verify field read/write access and business rules."
    }
}

$certBody = @{ name = "$EntraIDSAMLDisplayName SAML"; pem_certificate = $pem; format = 'PEM' }
if ($existingCert.sys_id) {
    Write-Host "Updating ServiceNow signing certificate $($existingCert.sys_id)"
    $certId = $existingCert.sys_id
    $null = Invoke-ServiceNowApi -Method Patch -RelativeUri "sys_certificate/$certId" -Body $certBody
}
else {
    Write-Host 'Creating ServiceNow signing certificate'
    $createdCert = Invoke-ServiceNowApi -Method Post -RelativeUri 'sys_certificate' -Body $certBody
    $certId = $createdCert.sys_id
}
if ($certId -notmatch '^[0-9a-f]{32}$') { throw 'ServiceNow did not return a valid signing certificate sys_id.' }
$savedCert = Invoke-ServiceNowApi -RelativeUri "sys_certificate/${certId}?sysparm_fields=name,pem_certificate,format"
if ([string]$savedCert.name -cne [string]$certBody.name -or
    ([string]$savedCert.pem_certificate -replace '\s', '') -cne ($pem -replace '\s', '') -or
    [string]$savedCert.format -ine 'PEM') {
    throw "ServiceNow did not persist signing certificate $certId. Verify read/write access to name, pem_certificate, and format."
}
$linkQuery = [Uri]::EscapeDataString("idp=$idpId^x509_certificate=$certId")
$linkUri = "idp_certificate?sysparm_query=$linkQuery&sysparm_fields=sys_id,idp,x509_certificate&sysparm_display_value=all&sysparm_exclude_reference_link=true&sysparm_limit=1"
$existingLink = @(Invoke-ServiceNowApi -RelativeUri $linkUri) | Select-Object -First 1
if (-not $existingLink.sys_id) {
    Write-Host 'Linking the signing certificate to the ServiceNow IdP'
    $createdLink = Invoke-ServiceNowApi -Method Post -RelativeUri 'idp_certificate' -Body @{ idp = $idpId; x509_certificate = $certId }
    if ($createdLink.sys_id -notmatch '^[0-9a-f]{32}$') { throw 'ServiceNow did not confirm the certificate link.' }
}
$savedLink = @(Invoke-ServiceNowApi -RelativeUri $linkUri) | Select-Object -First 1
if (-not $savedLink.sys_id -or $savedLink.idp.value -ne $idpId -or $savedLink.x509_certificate.value -ne $certId) {
    throw 'ServiceNow did not verify the IdP certificate link. Verify read/create access to the link and its reference fields.'
}

$redirectQuery = [Uri]::EscapeDataString('name=glide.authenticate.sso.redirect.idp')
$redirectProperty = @(Invoke-ServiceNowApi -RelativeUri "sys_properties?sysparm_query=$redirectQuery&sysparm_fields=sys_id,name,value&sysparm_limit=2")
if ($redirectProperty.Count -gt 1) { throw 'ServiceNow returned multiple auto-redirect properties. No redirect change was saved.' }
if (-not $redirectProperty.sys_id) {
    Write-Host 'Creating the ServiceNow auto-redirect property'
    $createdRedirect = Invoke-ServiceNowApi -Method Post -RelativeUri 'sys_properties' -Body @{
        name = 'glide.authenticate.sso.redirect.idp'
        value = $idpId
        type = 'string'
        description = 'sys_id of the identity provider that unauthenticated users are redirected to.'
    }
    if ($createdRedirect.sys_id -notmatch '^[0-9a-f]{32}$') { throw 'ServiceNow did not return a valid auto-redirect property sys_id.' }
    $redirectProperty = [pscustomobject]@{ sys_id = $createdRedirect.sys_id; value = $idpId }
}
elseif ([string]$redirectProperty.value -ne $idpId) {
    if ([string]::IsNullOrWhiteSpace([string]$redirectProperty.value)) {
        Write-Host 'Enabling automatic redirect to the Entra identity provider'
    }
    else {
        Write-Warning "Replacing auto-redirect IdP $($redirectProperty.value) with $idpId."
    }
    $null = Invoke-ServiceNowApi -Method Patch -RelativeUri "sys_properties/$($redirectProperty.sys_id)" -Body @{ value = $idpId }
}
$savedRedirect = Invoke-ServiceNowApi -RelativeUri "sys_properties/$($redirectProperty.sys_id)?sysparm_fields=name,value"
if ($savedRedirect.name -ne 'glide.authenticate.sso.redirect.idp' -or [string]$savedRedirect.value -ne $idpId) {
    throw 'ServiceNow did not persist the auto-redirect identity provider. Verify read/write access to glide.authenticate.sso.redirect.idp.'
}

$signOnUrl = "$ServiceNowInstance/login_with_sso.do?glide_sso_id=$idpId"
$null = Invoke-Graph -Method Patch -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$($servicePrincipal.id)" -WaitForReplication:$newServicePrincipal -Body @{ loginUrl = $signOnUrl }
$null = Invoke-Graph -Method Patch -Uri "https://graph.microsoft.com/v1.0/applications/$($application.id)" -WaitForReplication:$newApplication -Body @{
    web = @{ redirectUris = @($replyUrl, "$ServiceNowInstance/consumer.do", "$ServiceNowInstance/saml_redirector.do?glide_sso_id=$idpId") }
}
[pscustomobject][ordered]@{
    DisplayName = $EntraIDSAMLDisplayName
    AppId = $application.appId
    TenantId = $context.Tenant.Id
    Identifier = $identifier
    ReplyUrl = $replyUrl
    SignOnUrl = $signOnUrl
    FederationMetadataUrl = $metadataUrl
    IdentityProviderSysId = $idpId
    AutoRedirectIdp = $savedRedirect.value
    LocalLoginUrl = "$ServiceNowInstance/side_door.do"
    SigningCertificateSysId = $certId
    UserField = $UserField
    AssignedEntraUser = $signedInUser.userPrincipalName
    UserAppRoleAssignmentId = $currentUserAssignment.id
}
